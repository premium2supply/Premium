import { formatMoney } from "./store.js";

export function productCard(product, site) {
  const img = (product.images && product.images[0]) || "assets/img/placeholder.svg";
  const isSale = !!product.onSale && product.salePrice != null;
  const price = Number(product.price || 0);
  const sale = Number(product.salePrice || 0);

  const priceHtml = isSale
    ? `<div class="price-row">
        <div class="price">${formatMoney(sale, site)}</div>
        <div class="price old">${formatMoney(price, site)}</div>
      </div>`
    : `<div class="price-row"><div class="price">${formatMoney(price, site)}</div></div>`;

  return `
    <a class="card" href="product.html?id=${encodeURIComponent(product.id)}">
      ${isSale ? `<div class="sale-pill">SALE</div>` : ""}
      <div class="img"><img src="${img}" alt="${escapeHtml(product.name)}" loading="lazy" onerror="this.src='assets/img/placeholder.svg'"></div>
      <div class="body">
        <div class="name">${escapeHtml(product.name)}</div>
        ${product.shortDescription ? `<div class="muted" style="font-size:13px;line-height:1.35">${escapeHtml(product.shortDescription)}</div>` : ""}
        ${priceHtml}
      </div>
    </a>
  `;
}

export function renderProductGrid(container, products, site, emptyText = "Aucun produit pour le moment.") {
  if (!container) return;
  if (!products.length) {
    container.innerHTML = `<div class="muted">${emptyText}</div>`;
    return;
  }
  container.innerHTML = products.map(p => productCard(p, site)).join("");
}

export function categoryCard(cat) {
  const isPromo = cat.id === "promo";
  return `
    <a class="category-card ${isPromo ? "promo" : ""}" href="shop.html?cat=${encodeURIComponent(cat.id)}">
      <div class="inner">
        <div class="title"><span aria-hidden="true">${cat.emoji || "•"}</span> ${escapeHtml(cat.label)}</div>
        <div class="desc">${escapeHtml(cat.description || "")}</div>
      </div>
    </a>
  `;
}

export function renderCategories(container, categories) {
  if (!container) return;
  container.innerHTML = (categories || []).slice(0,6).map(categoryCard).join("");
}

export function sortByCreatedAtDesc(products) {
  return [...products].sort((a,b) => {
    const da = Date.parse(a.createdAt || "") || 0;
    const db = Date.parse(b.createdAt || "") || 0;
    return db - da;
  });
}

export function escapeHtml(str) {
  return String(str ?? "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}
