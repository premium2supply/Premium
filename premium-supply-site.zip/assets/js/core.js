import { getSite, getCartCount } from "./store.js";

async function inject(id, url) {
  const el = document.getElementById(id);
  if (!el) return;
  const res = await fetch(url, { cache: "no-store" });
  el.innerHTML = await res.text();
}

/** Build category chips in the header. */
function renderCategoryBar(site) {
  const bar = document.getElementById("category-bar");
  if (!bar) return;

  bar.innerHTML = "";
  (site.categories || []).slice(0, 6).forEach(cat => {
    const a = document.createElement("a");
    a.className = "category-chip" + (cat.id === "promo" ? " promo" : "");
    a.href = `shop.html?cat=${encodeURIComponent(cat.id)}`;
    a.innerHTML = `<span aria-hidden="true">${cat.emoji || "•"}</span><span>${cat.label}</span>`;
    bar.appendChild(a);
  });
}

function applyPromoBar(site) {
  const bar = document.getElementById("promo-bar");
  const text = document.getElementById("promo-bar-text");
  const link = document.getElementById("promo-bar-link");
  if (!bar || !text || !link) return;

  if (site.promoBanner?.enabled) {
    text.textContent = site.promoBanner.text || "SALE";
    link.setAttribute("href", site.promoBanner.link || "promo.html");
    bar.hidden = false;
  } else {
    bar.hidden = true;
  }
}

function applyBrand(site) {
  const name = site.storeName || "Premium Supply";
  const brandName = document.getElementById("brand-name");
  if (brandName) brandName.textContent = name;

  const footerBrand = document.getElementById("footer-brand");
  if (footerBrand) footerBrand.textContent = name;

  // Replace placeholder in title (optional)
  if (document.title.includes("Premium Supply")) {
    document.title = document.title.replace("Premium Supply", name);
  }
}

export function setCartCount(count) {
  const el = document.getElementById("cart-count");
  if (el) el.textContent = String(count);
}

function setupMobileNav() {
  const toggle = document.getElementById("nav-toggle");
  const nav = document.getElementById("nav");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
  });

  // close when clicking outside
  document.addEventListener("click", (e) => {
    if (!nav.classList.contains("open")) return;
    const t = e.target;
    if (nav.contains(t) || toggle.contains(t)) return;
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  });
}

/** Init header/footer + global listeners. */
export async function initLayout() {
  await inject("site-header", "partials/header.html");
  await inject("site-footer", "partials/footer.html");

  const site = await getSite();

  applyBrand(site);
  applyPromoBar(site);
  renderCategoryBar(site);
  setupMobileNav();

  setCartCount(getCartCount());
  window.addEventListener("cart:change", () => {
    setCartCount(getCartCount());
  });

  return { site };
}

/** Small helper: read URL query param. */
export function qp(name) {
  const u = new URL(window.location.href);
  return u.searchParams.get(name);
}
