const CACHE = {
  site: null,
  products: null,
};

/** Fetch JSON helper (works on GitHub Pages). */
async function fetchJSON(path) {
  const res = await fetch(path, { cache: "no-store" });
  if (!res.ok) {
    throw new Error(`Impossible de charger ${path} (HTTP ${res.status})`);
  }
  return await res.json();
}

export async function getSite() {
  if (CACHE.site) return CACHE.site;
  CACHE.site = await fetchJSON("data/site.json");
  return CACHE.site;
}

export async function getProducts() {
  if (CACHE.products) return CACHE.products;
  CACHE.products = await fetchJSON("data/products.json");
  return CACHE.products;
}

export async function getProductById(id) {
  const products = await getProducts();
  return products.find(p => p.id === id) || null;
}

export function formatMoney(amount, site) {
  const value = Number(amount ?? 0);
  const locale = site?.locale || "fr-CA";
  const currency = site?.currency || "CAD";
  try{
    return new Intl.NumberFormat(locale, { style: "currency", currency }).format(value);
  }catch{
    const symbol = site?.currencySymbol || "$";
    return `${value.toFixed(2)} ${symbol}`;
  }
}

/* =========================
   Cart (localStorage)
   ========================= */

const CART_KEY = "ps_cart_v1";

export function getCart() {
  try {
    const raw = localStorage.getItem(CART_KEY);
    const cart = raw ? JSON.parse(raw) : [];
    return Array.isArray(cart) ? cart : [];
  } catch {
    return [];
  }
}

export function setCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  window.dispatchEvent(new CustomEvent("cart:change", { detail: { cart } }));
}

export function getCartCount() {
  return getCart().reduce((sum, it) => sum + (Number(it.qty) || 0), 0);
}

export async function addToCart(productId, qty = 1) {
  const site = await getSite();
  const products = await getProducts();
  const product = products.find(p => p.id === productId);
  if (!product) throw new Error("Produit introuvable.");

  const maxQty = Number(product.maxQty ?? site.maxQtyPerItemDefault ?? 20);
  const addQty = clampInt(qty, 1, maxQty);

  const cart = getCart();
  const existing = cart.find(i => i.id === productId);

  if (existing) {
    existing.qty = clampInt((Number(existing.qty) || 0) + addQty, 1, maxQty);
  } else {
    cart.push({ id: productId, qty: addQty });
  }
  setCart(cart);
}

export async function updateCartQty(productId, qty) {
  const site = await getSite();
  const products = await getProducts();
  const product = products.find(p => p.id === productId);
  const maxQty = Number(product?.maxQty ?? site.maxQtyPerItemDefault ?? 20);

  const newQty = clampInt(qty, 0, maxQty);
  const cart = getCart();

  const idx = cart.findIndex(i => i.id === productId);
  if (idx === -1) return;

  if (newQty <= 0) cart.splice(idx, 1);
  else cart[idx].qty = newQty;

  setCart(cart);
}

export function removeFromCart(productId) {
  const cart = getCart().filter(i => i.id !== productId);
  setCart(cart);
}

export function clearCart() {
  setCart([]);
}

export async function getCartDetailed() {
  const products = await getProducts();
  const cart = getCart();

  const lines = cart.map(it => {
    const p = products.find(pp => pp.id === it.id);
    if (!p) return null;
    const qty = Number(it.qty) || 0;
    const unit = Number(p.onSale && p.salePrice != null ? p.salePrice : p.price);
    const unitOld = Number(p.price);
    const lineTotal = unit * qty;
    const savings = p.onSale && p.salePrice != null ? (unitOld - unit) * qty : 0;

    return {
      id: p.id,
      name: p.name,
      category: p.category,
      image: (p.images && p.images[0]) || "assets/img/placeholder.svg",
      onSale: !!p.onSale,
      price: unitOld,
      salePrice: p.salePrice,
      unitPrice: unit,
      qty,
      lineTotal,
      savings,
    };
  }).filter(Boolean);

  const subtotal = lines.reduce((s, l) => s + l.lineTotal, 0);
  const totalSavings = lines.reduce((s, l) => s + (l.savings || 0), 0);

  // shipping / tax placeholders (editable later)
  const shipping = 0;
  const tax = 0;
  const total = subtotal + shipping + tax;

  return { lines, subtotal, shipping, tax, totalSavings, total };
}

/* =========================
   Orders (local only)
   ========================= */

const LAST_ORDER_KEY = "ps_last_order_v1";

export function generateOrderId(prefix = "PS") {
  const rand = Math.random().toString(16).slice(2, 8).toUpperCase();
  const ts = Date.now().toString(16).slice(-6).toUpperCase();
  return `${prefix}-${ts}-${rand}`;
}

export function saveLastOrder(order) {
  localStorage.setItem(LAST_ORDER_KEY, JSON.stringify(order));
}

export function loadLastOrder() {
  try {
    const raw = localStorage.getItem(LAST_ORDER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clampInt(value, min, max) {
  const n = Math.floor(Number(value));
  if (Number.isNaN(n)) return min;
  return Math.min(max, Math.max(min, n));
}
