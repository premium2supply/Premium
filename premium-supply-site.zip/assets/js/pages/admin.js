import { initLayout } from "../core.js";
import { getSite, getProducts } from "../store.js";
import { escapeHtml } from "../ui.js";

function $(id){ return document.getElementById(id); }

function downloadFile(filename, content, mime="application/json") {
  const blob = new Blob([content], { type: mime });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

function asFloat(v){
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}

function asBool(v){ return !!v; }

function nowDate(){
  return new Date().toISOString().slice(0,10);
}

(async () => {
  await initLayout();
  const site = await getSite();

  const categories = site.categories || [];

  // Fill category select
  const catSelect = $("p-category");
  catSelect.innerHTML = categories.map(c => `<option value="${c.id}">${c.label}</option>`).join("");

  let products = await getProducts();
  // clone (we don't want to mutate cache in store.js)
  products = JSON.parse(JSON.stringify(products));

  function renderTable() {
    const tbody = $("admin-table-body");
    tbody.innerHTML = products.map(p => `
      <tr>
        <td style="font-weight:950">${escapeHtml(p.name)}</td>
        <td>
          <div>${escapeHtml(p.id)}</div>
          <div class="mini">${escapeHtml(categories.find(c => c.id === p.category)?.label || p.category)}</div>
        </td>
        <td>${asBool(p.onSale) && p.salePrice != null ? `SALE (${escapeHtml(p.salePrice)})` : "—"}</td>
        <td>
          <button class="btn small" data-act="edit" data-id="${escapeHtml(p.id)}">Modifier</button>
          <button class="btn small danger" data-act="del" data-id="${escapeHtml(p.id)}">Supprimer</button>
        </td>
      </tr>
    `).join("");

    tbody.querySelectorAll("button[data-act]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-id");
        const act = btn.getAttribute("data-act");
        if (act === "edit") editProduct(id);
        if (act === "del") deleteProduct(id);
      });
    });

    $("admin-count").textContent = `${products.length} produit(s)`;
  }

  function resetForm() {
    $("p-id").value = "";
    $("p-name").value = "";
    $("p-short").value = "";
    $("p-desc").value = "";
    $("p-details").value = "";
    $("p-price").value = "";
    $("p-sale").value = "";
    $("p-onsale").checked = false;
    $("p-badge").value = "";
    $("p-images").value = "";
    $("p-createdAt").value = nowDate();
    $("p-maxQty").value = "";
    $("p-id").disabled = false;
    $("save-label").textContent = "Ajouter";
  }

  function editProduct(id) {
    const p = products.find(x => x.id === id);
    if (!p) return;
    $("p-id").value = p.id || "";
    $("p-name").value = p.name || "";
    $("p-short").value = p.shortDescription || "";
    $("p-desc").value = p.description || "";
    $("p-details").value = Array.isArray(p.details) ? p.details.join("\n") : "";
    $("p-price").value = p.price ?? "";
    $("p-onsale").checked = !!p.onSale;
    $("p-sale").value = p.salePrice ?? "";
    $("p-badge").value = p.badge || "";
    $("p-category").value = p.category || categories[0]?.id || "";
    $("p-images").value = Array.isArray(p.images) ? p.images.join(", ") : "";
    $("p-createdAt").value = p.createdAt || nowDate();
    $("p-maxQty").value = p.maxQty ?? "";
    $("p-id").disabled = true;
    $("save-label").textContent = "Mettre à jour";
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function deleteProduct(id) {
    if (!confirm("Supprimer ce produit ?")) return;
    products = products.filter(p => p.id !== id);
    resetForm();
    renderTable();
  }

  function readForm() {
    const id = $("p-id").value.trim();
    const name = $("p-name").value.trim();
    const category = $("p-category").value;
    if (!id || !name || !category) {
      alert("ID, Nom et Catégorie sont obligatoires.");
      return null;
    }

    const details = $("p-details").value
      .split("\n")
      .map(s => s.trim())
      .filter(Boolean);

    const images = $("p-images").value
      .split(",")
      .map(s => s.trim())
      .filter(Boolean);

    const onSale = $("p-onsale").checked;
    const salePrice = $("p-sale").value.trim() ? asFloat($("p-sale").value) : null;

    return {
      id,
      name,
      category,
      shortDescription: $("p-short").value.trim(),
      description: $("p-desc").value.trim(),
      details,
      price: asFloat($("p-price").value),
      onSale,
      salePrice: onSale ? salePrice : null,
      badge: $("p-badge").value.trim(),
      images: images.length ? images : ["assets/img/placeholder.svg"],
      createdAt: $("p-createdAt").value || nowDate(),
      maxQty: $("p-maxQty").value.trim() ? Number($("p-maxQty").value) : undefined,
    };
  }

  $("product-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const data = readForm();
    if (!data) return;

    const exists = products.find(p => p.id === data.id);
    if (exists) {
      Object.assign(exists, data);
    } else {
      products.unshift(data);
    }

    renderTable();
    resetForm();
    alert("OK ✅ Produit prêt. Pense à exporter products.json puis à remplacer data/products.json dans ton repo.");
  });

  $("reset-form").addEventListener("click", resetForm);

  $("export-json").addEventListener("click", () => {
    const text = JSON.stringify(products, null, 2);
    downloadFile("products.json", text);
  });

  $("copy-snippet").addEventListener("click", async () => {
    const data = readForm();
    if (!data) return;
    const snippet = JSON.stringify(data, null, 2);
    try{
      await navigator.clipboard.writeText(snippet);
      alert("Snippet copié ✅ Colle-le dans data/products.json (entre les crochets).");
    }catch{
      alert("Impossible de copier automatiquement. Voici le snippet dans la console.");
      console.log(snippet);
    }
  });

  $("import-json").addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    try{
      const parsed = JSON.parse(text);
      if (!Array.isArray(parsed)) throw new Error("JSON invalide: on attend un tableau []");
      products = parsed;
      renderTable();
      resetForm();
      alert("Import OK ✅");
    }catch(err){
      alert("Import impossible: " + err.message);
    }
  });

  resetForm();
  renderTable();
})();
