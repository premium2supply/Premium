import { initLayout, qp } from "../core.js";
import { getProducts } from "../store.js";
import { renderProductGrid, sortByCreatedAtDesc } from "../ui.js";

function updateUrl(params) {
  const u = new URL(window.location.href);
  Object.entries(params).forEach(([k,v]) => {
    if (v === null || v === "" || v === false) u.searchParams.delete(k);
    else u.searchParams.set(k, String(v));
  });
  window.history.replaceState({}, "", u.toString());
}

(async () => {
  const { site } = await initLayout();
  const products = await getProducts();

  const grid = document.getElementById("shop-grid");
  const countEl = document.getElementById("results-count");
  const catSelect = document.getElementById("filter-category");
  const searchInput = document.getElementById("filter-search");
  const saleToggle = document.getElementById("filter-sale");
  const resetBtn = document.getElementById("filter-reset");
  const titleEl = document.getElementById("shop-title");

  // Fill category select
  const cats = site.categories || [];
  catSelect.innerHTML = `<option value="">Toutes les catégories</option>` + cats.map(c => `<option value="${c.id}">${c.label}</option>`).join("");

  // Initial state from URL
  const state = {
    cat: qp("cat") || "",
    q: qp("q") || "",
    sale: qp("sale") === "1" || qp("sale") === "true",
  };

  catSelect.value = state.cat;
  searchInput.value = state.q;
  saleToggle.checked = state.sale;

  function apply() {
    const cat = catSelect.value || "";
    const q = (searchInput.value || "").trim().toLowerCase();
    const sale = !!saleToggle.checked;

    // title
    const catLabel = cats.find(c => c.id === cat)?.label;
    if (titleEl) titleEl.textContent = catLabel ? `Shop — ${catLabel}` : "Shop";

    // filter
    let list = [...products];
    if (cat) list = list.filter(p => p.category === cat);
    if (sale) list = list.filter(p => p.onSale && p.salePrice != null);
    if (q) list = list.filter(p => {
      const hay = `${p.name} ${p.shortDescription || ""} ${p.description || ""}`.toLowerCase();
      return hay.includes(q);
    });

    list = sortByCreatedAtDesc(list);

    renderProductGrid(grid, list, site, "Aucun produit trouvé avec ces filtres.");
    if (countEl) countEl.textContent = `${list.length} produit(s)`;
    updateUrl({ cat: cat || null, q: q || null, sale: sale ? 1 : null });
  }

  catSelect.addEventListener("change", apply);
  saleToggle.addEventListener("change", apply);
  searchInput.addEventListener("input", () => {
    window.clearTimeout(window.__ps_searchT);
    window.__ps_searchT = window.setTimeout(apply, 120);
  });

  resetBtn.addEventListener("click", () => {
    catSelect.value = "";
    searchInput.value = "";
    saleToggle.checked = false;
    apply();
  });

  // Quick links
  const promoBtn = document.getElementById("go-promo");
  if (promoBtn) promoBtn.addEventListener("click", () => {
    saleToggle.checked = true;
    apply();
    window.scrollTo({ top: grid.offsetTop - 90, behavior: "smooth" });
  });

  apply();
})();
