import { initLayout } from "../core.js";
import { getSite, getCartDetailed, formatMoney, generateOrderId, saveLastOrder, clearCart } from "../store.js";
import { escapeHtml } from "../ui.js";

function $(id){ return document.getElementById(id); }

function renderEmpty() {
  $("checkout-main").innerHTML = `<div class="panel"><h3>Panier vide</h3><p class="muted">Ajoute au moins un produit avant de passer au checkout.</p><a class="btn primary" href="shop.html">Aller au shop</a></div>`;
}

(async () => {
  await initLayout();
  const site = await getSite();

  const data = await getCartDetailed();
  if (!data.lines.length) {
    renderEmpty();
    return;
  }

  // Order summary
  $("checkout-items").innerHTML = data.lines.map(l => `
    <div class="summary-row" style="align-items:flex-start">
      <div style="max-width:70%">
        <strong>${escapeHtml(l.name)}</strong>
        <div class="muted" style="font-size:12px;margin-top:2px">x${l.qty}</div>
      </div>
      <div>${formatMoney(l.lineTotal, site)}</div>
    </div>
  `).join("");

  $("checkout-total").textContent = formatMoney(data.total, site);

  // Directives
  const dirWrap = $("directives");
  const directives = site.checkout?.directives || [];
  dirWrap.innerHTML = directives.map((txt, idx) => `
    <label class="check-item">
      <input type="checkbox" class="dir-check" data-idx="${idx}">
      <div>${escapeHtml(txt)}</div>
    </label>
  `).join("");

  const btn = $("place-order");
  const form = $("checkout-form");

  function updateBtn() {
    const checks = Array.from(document.querySelectorAll(".dir-check"));
    const ok = checks.every(c => c.checked);
    btn.disabled = !ok;
  }
  document.querySelectorAll(".dir-check").forEach(c => c.addEventListener("change", updateBtn));
  updateBtn();

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const fd = new FormData(form);
    const customer = {
      email: String(fd.get("email") || "").trim(),
      name: String(fd.get("name") || "").trim(),
      phone: String(fd.get("phone") || "").trim(),
      address1: String(fd.get("address1") || "").trim(),
      address2: String(fd.get("address2") || "").trim(),
      city: String(fd.get("city") || "").trim(),
      region: String(fd.get("region") || "").trim(),
      postal: String(fd.get("postal") || "").trim(),
      country: String(fd.get("country") || "").trim(),
      note: String(fd.get("note") || "").trim(),
    };

    // Minimal validation
    const required = ["email","name","address1","city","postal","country"];
    const missing = required.filter(k => !customer[k]);
    if (missing.length) {
      alert("Merci de remplir les champs obligatoires.");
      return;
    }

    const order = {
      id: generateOrderId("PS"),
      createdAt: new Date().toISOString(),
      customer,
      items: data.lines.map(l => ({ id: l.id, name: l.name, qty: l.qty, unitPrice: l.unitPrice, lineTotal: l.lineTotal })),
      totals: {
        subtotal: data.subtotal,
        shipping: data.shipping,
        tax: data.tax,
        total: data.total,
        savings: data.totalSavings,
      }
    };

    saveLastOrder(order);
    clearCart();

    window.location.href = `confirmation.html?order=${encodeURIComponent(order.id)}`;
  });

})();
