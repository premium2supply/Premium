import { initLayout, qp } from "../core.js";
import { getSite, loadLastOrder, formatMoney } from "../store.js";
import { escapeHtml } from "../ui.js";

function $(id){ return document.getElementById(id); }

(async () => {
  await initLayout();
  const site = await getSite();

  const order = loadLastOrder();
  const requested = qp("order");

  if (!order || (requested && order.id !== requested)) {
    $("confirm").innerHTML = `
      <div class="panel">
        <h3>Aucune commande trouvée</h3>
        <p class="muted">Si tu viens de confirmer une commande, recharge la page. Sinon, retourne au shop.</p>
        <a class="btn primary" href="shop.html">Aller au shop</a>
      </div>
    `;
    return;
  }

  $("order-id").textContent = order.id;
  $("order-date").textContent = new Date(order.createdAt).toLocaleString(site.locale || "fr-CA");

  $("confirm-items").innerHTML = order.items.map(it => `
    <div class="summary-row" style="align-items:flex-start">
      <div style="max-width:70%">
        <strong>${escapeHtml(it.name)}</strong>
        <div class="muted" style="font-size:12px;margin-top:2px">x${it.qty}</div>
      </div>
      <div>${formatMoney(it.lineTotal, site)}</div>
    </div>
  `).join("");

  $("confirm-total").textContent = formatMoney(order.totals.total, site);

  // Payment instructions (editable in data/site.json)
  const pay = site.checkout?.paymentInstructions || [];
  $("payment-instructions").innerHTML = pay.map(p => `<li>${escapeHtml(p)}</li>`).join("");

})();
