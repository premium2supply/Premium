import { initLayout } from "../core.js";
import { getSite, getCartDetailed, updateCartQty, removeFromCart, clearCart, formatMoney } from "../store.js";
import { escapeHtml } from "../ui.js";

function $(id){ return document.getElementById(id); }

function renderEmpty() {
  $("cart-items").innerHTML = `<div style="padding:16px" class="muted">Ton panier est vide. <a href="shop.html">Aller au shop</a></div>`;
  $("cart-summary").classList.add("hidden");
}

(async () => {
  await initLayout();
  const site = await getSite();

  async function render() {
    const { lines, subtotal, shipping, tax, total, totalSavings } = await getCartDetailed();
    const itemsEl = $("cart-items");
    const summaryEl = $("cart-summary");

    if (!lines.length) {
      renderEmpty();
      return;
    }

    summaryEl.classList.remove("hidden");

    itemsEl.innerHTML = lines.map(line => {
      const max = Number(line.maxQty || site.maxQtyPerItemDefault || 20);
      const unitText = line.onSale ? formatMoney(line.unitPrice, site) : formatMoney(line.unitPrice, site);
      const oldText = line.onSale ? `<div class="muted" style="font-size:12px;text-decoration:line-through">${formatMoney(line.price, site)}</div>` : "";
      return `
        <div class="cart-row" data-id="${escapeHtml(line.id)}">
          <img src="${line.image}" alt="${escapeHtml(line.name)}" loading="lazy" onerror="this.src='assets/img/placeholder.svg'">
          <div>
            <div class="title">${escapeHtml(line.name)}</div>
            <div class="sub">${unitText} ${oldText}</div>
          </div>
          <div class="qty">
            <input class="input qty-input" type="number" min="1" max="${max}" value="${line.qty}" inputmode="numeric">
          </div>
          <div class="line-total" style="font-weight:950">${formatMoney(line.lineTotal, site)}</div>
          <div class="remove" title="Supprimer">✕</div>
        </div>
      `;
    }).join("");

    $("sum-subtotal").textContent = formatMoney(subtotal, site);
    $("sum-shipping").textContent = formatMoney(shipping, site);
    $("sum-tax").textContent = formatMoney(tax, site);
    $("sum-total").textContent = formatMoney(total, site);

    const savingsEl = $("sum-savings");
    if (savingsEl) {
      if (totalSavings > 0.01) {
        savingsEl.textContent = `Économies: ${formatMoney(totalSavings, site)}`;
        savingsEl.classList.remove("hidden");
      } else {
        savingsEl.classList.add("hidden");
      }
    }

    // events
    itemsEl.querySelectorAll(".cart-row").forEach(row => {
      const id = row.getAttribute("data-id");
      row.querySelector(".qty-input")?.addEventListener("change", async (e) => {
        await updateCartQty(id, e.target.value);
        await render();
      });
      row.querySelector(".remove")?.addEventListener("click", async () => {
        removeFromCart(id);
        await render();
      });
    });
  }

  $("clear-cart")?.addEventListener("click", async () => {
    clearCart();
    await render();
  });

  await render();
})();
