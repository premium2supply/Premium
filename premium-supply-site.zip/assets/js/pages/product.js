import { initLayout, qp } from "../core.js";
import { getProductById, getSite, addToCart, formatMoney, clampInt } from "../store.js";
import { escapeHtml } from "../ui.js";

function setHtml(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}
function setText(id, txt) {
  const el = document.getElementById(id);
  if (el) el.textContent = txt;
}
function showToast(msg) {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("show");
  window.clearTimeout(window.__toastT);
  window.__toastT = window.setTimeout(() => el.classList.remove("show"), 2200);
}

(async () => {
  await initLayout();
  const site = await getSite();

  const id = qp("id");
  if (!id) {
    setText("product-name", "Produit introuvable");
    return;
  }

  const product = await getProductById(id);
  if (!product) {
    setText("product-name", "Produit introuvable");
    return;
  }

  setText("product-name", product.name);
  setText("product-short", product.shortDescription || "");
  setText("product-desc", product.description || "");
  setText("product-category", (site.categories || []).find(c => c.id === product.category)?.label || product.category);

  const img = (product.images && product.images[0]) || "assets/img/placeholder.svg";
  const imgEl = document.getElementById("product-image");
  if (imgEl) {
    imgEl.src = img;
    imgEl.alt = product.name;
    imgEl.onerror = () => { imgEl.src = "assets/img/placeholder.svg"; };
  }

  const isSale = !!product.onSale && product.salePrice != null;
  const price = Number(product.price || 0);
  const sale = Number(product.salePrice || 0);

  if (isSale) {
    setHtml("product-price", `<div class="price-row"><div class="price">${formatMoney(sale, site)}</div><div class="price old">${formatMoney(price, site)}</div><span class="badge" style="border-color:rgba(255,59,107,0.25);background:rgba(255,59,107,0.12)">SALE</span></div>`);
  } else {
    setHtml("product-price", `<div class="price-row"><div class="price">${formatMoney(price, site)}</div></div>`);
  }

  // Details list
  const details = Array.isArray(product.details) ? product.details : [];
  setHtml("product-details", details.length ? details.map(d => `<li>${escapeHtml(d)}</li>`).join("") : `<li class="muted">Ajoute tes détails produit ici.</li>`);

  // Qty & add to cart
  const maxQty = Number(product.maxQty ?? site.maxQtyPerItemDefault ?? 20);
  const qtyInput = document.getElementById("qty");
  const addBtn = document.getElementById("add-to-cart");
  if (qtyInput) {
    qtyInput.min = "1";
    qtyInput.max = String(maxQty);
    qtyInput.value = "1";
  }

  addBtn?.addEventListener("click", async () => {
    const qty = clampInt(qtyInput?.value || 1, 1, maxQty);
    await addToCart(product.id, qty);
    showToast(`Ajouté au panier (${qty}) ✅`);
  });

})();
