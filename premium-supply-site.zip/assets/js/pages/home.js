import { initLayout } from "../core.js";
import { getProducts } from "../store.js";
import { renderProductGrid, renderCategories, sortByCreatedAtDesc } from "../ui.js";

(async () => {
  const { site } = await initLayout();
  const products = await getProducts();

  // Tagline
  const taglineEl = document.getElementById("tagline");
  if (taglineEl) taglineEl.textContent = site.tagline || "";

  // 6 categories
  renderCategories(document.getElementById("categories-grid"), site.categories || []);

  // Hot drops
  const hotId = site.home?.hotDropsCategoryId || "hot-drops";
  const hot = sortByCreatedAtDesc(products.filter(p => p.category === hotId)).slice(0, site.home?.hotDropsLimit || 8);
  renderProductGrid(document.getElementById("hot-drops-grid"), hot, site, "Aucun Hot Drop pour le moment.");

  // Promo (onSale)
  const promo = sortByCreatedAtDesc(products.filter(p => p.onSale && p.salePrice != null)).slice(0, site.home?.promoLimit || 8);
  renderProductGrid(document.getElementById("promo-grid"), promo, site, "Aucune promo active pour le moment.");

})();
