import { initLayout } from "../core.js";
import { getProducts } from "../store.js";
import { renderProductGrid, sortByCreatedAtDesc } from "../ui.js";

(async () => {
  const { site } = await initLayout();
  const products = await getProducts();

  const promo = sortByCreatedAtDesc(products.filter(p => p.onSale && p.salePrice != null));
  renderProductGrid(document.getElementById("promo-grid"), promo, site, "Aucune promo active pour le moment.");
})();
