# Premium Supply (static shop)

Ce projet est un mini shop **100% statique** (compatible GitHub Pages) avec :

- 6 catégories (configurables)
- une **promo très visible** (bannière + page dédiée + badges SALE)
- un **panier** (localStorage)
- un **checkout simple** + “directives avant achat” (checkbox obligatoires)
- un petit **outil Admin** pour générer / exporter `products.json`

## Où modifier quoi ?

### Catégories + bannière promo + directives checkout
`/data/site.json`

### Produits
`/data/products.json`

Champs importants :
- `onSale: true` + `salePrice: 54` → produit en promo (badge SALE + affichage prix barré)
- `category` → doit correspondre à un `id` de catégorie dans `data/site.json`
- `images` → liste de chemins vers des images dans `assets/img/products/`

### Photos produit
Mets tes images dans :  
`/assets/img/products/`

Puis référence-les dans `data/products.json`, ex :
```json
"images": ["assets/img/products/mon-produit-1.jpg"]
```

## Admin

Ouvre `/admin.html` :
- ajoute/modifie des produits
- clique **Exporter products.json**
- remplace ensuite `/data/products.json` dans ton repo GitHub par le fichier exporté

## Déploiement GitHub Pages

1. Copie tous les fichiers dans ton repo
2. `Settings → Pages`
3. `Deploy from a branch` → `main` → `/root`
4. Le site se charge

